![GitHub issues](https://img.shields.io/github/issues/HoloKi/BitHeroesBot)
![GitHub branch checks state](https://img.shields.io/github/checks-status/HoloKi/BitHeroesBot/master)
![GitHub release (latest SemVer including pre-releases)](https://img.shields.io/github/v/release/HoloKi/BitHeroesBot?include_prereleases)
![GitHub last commit](https://img.shields.io/github/last-commit/HoloKi/BitHeroesBot)
![GitHub Repo stars](https://img.shields.io/github/stars/HoloKi/BitHeroesBot)

# Bit Heroes Bot
>This bot is completely free, any sale is strictly prohibited
>
>This bot is a macro, so it performs the various operations by having the screen free with the game and the script open

## Dipendencies

[Pyautogui](https://pyautogui.readthedocs.io/en/latest/)

## Language

>Italian
>
>English (planned)

## Help me

Support me with translate or with code.

**Discord contact**
>@HoloKi#
